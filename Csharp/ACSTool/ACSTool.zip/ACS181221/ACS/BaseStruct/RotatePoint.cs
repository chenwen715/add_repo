﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACS
{
    public class RotatePoint
    {
        /// <summary>
        /// 周围点
        /// </summary>
        public Point aroundPoint;
        /// <summary>
        /// 旋转点
        /// </summary>
        public Point rotatePoint;
    }
}
